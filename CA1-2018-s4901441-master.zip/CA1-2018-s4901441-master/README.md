# CA1-2018-s4901441
CA1-2018-s4901441 created by GitHub Classroom

This program implements a simple rigid-body and soft-body physics engine with a demonstrating particle system. This physics engine is impulse-based, with the ability to calculate gravity, collision and friction impulses and visualize the impact to particles.
I would recommend using default settings before going crazy:)
For implementation and algorithm design please check the report file.
